import React from "react";
import "./styles.css"
export default function SkyBackground() {
    return (
        <>
            <div className="stars"></div>
            <div className="twinkling"></div>
        </>
    );
}